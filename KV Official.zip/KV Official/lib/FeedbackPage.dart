import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';

class FeedbackPage extends StatefulWidget {
  @override
  _FeedbackPageState createState() => _FeedbackPageState();
}

class _FeedbackPageState extends State<FeedbackPage> {
  final _formKey = GlobalKey<FormState>();
  String rating = '';
  List<String> liked = [];
  List<String> improvements = [];
  String additionalComments = '';

  void _submitFeedback() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      String message = '''
      Rating: $rating
      Liked: ${liked.join(', ')}
      Improvements: ${improvements.join(', ')}
      Additional Comments: $additionalComments
      ''';

      _sendEmail(message);
    }
  }

  Future<void> _sendEmail(String message) async {
    final Uri emailUri = Uri(
      scheme: 'mailto',
      path: 'dummyemail@example.com',
      queryParameters: {
        'subject': 'App Feedback',
        'body': message,
      },
    );

    if (await canLaunch(emailUri.toString())) {
      await launch(emailUri.toString());
    } else {
      throw 'Could not launch email client';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          color: Color(0xFFFFFFFF),
        ),
        child: Form(
          key: _formKey,
          child: Padding(
            padding: EdgeInsets.fromLTRB(24, 0, 24, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Feedback',
                  style: GoogleFonts.inter(
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                    color: Color(0xFF1F2024),
                  ),
                ),
                // Rating Section
                Text('How would you rate our app?'),
                DropdownButtonFormField<String>(
                  items: ['1', '2', '3', '4', '5']
                      .map((value) => DropdownMenuItem(
                            child: Text(value),
                            value: value,
                          ))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      rating = value!;
                    });
                  },
                  onSaved: (value) {
                    rating = value!;
                  },
                  validator: (value) =>
                      value == null ? 'Please select a rating' : null,
                ),
                // Liked Section
                Text('What did you like about it?'),
                CheckboxListTile(
                  title: Text("Informative"),
                  value: liked.contains("Informative"),
                  onChanged: (bool? value) {
                    setState(() {
                      if (value == true) {
                        liked.add("Informative");
                      } else {
                        liked.remove("Informative");
                      }
                    });
                  },
                ),
                // Add more CheckboxListTile for other options...
                // Improvements Section
                Text('What could be improved?'),
                CheckboxListTile(
                  title: Text("Navigation"),
                  value: improvements.contains("Navigation"),
                  onChanged: (bool? value) {
                    setState(() {
                      if (value == true) {
                        improvements.add("Navigation");
                      } else {
                        improvements.remove("Navigation");
                      }
                    });
                  },
                ),
                // Add more CheckboxListTile for other options...
                // Additional Comments
                TextFormField(
                  decoration: InputDecoration(labelText: 'Anything else?'),
                  onSaved: (value) {
                    additionalComments = value ?? '';
                  },
                ),
                // Submit Button
                ElevatedButton(
                  onPressed: _submitFeedback,
                  child: Text('Submit'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}